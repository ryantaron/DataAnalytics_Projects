/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectstartup;

/**
 *
 * @author Administrator
 */
import javax.swing.JOptionPane;
public class Validator {
    public static String getValidVIN(String input){
       
        //loop to make sure input is valid
        while(isValidVIN(input) == false){
        
            input = JOptionPane.showInputDialog(null, "VIN: " + input + " is invalid\n\nPlease reenter a valid VIN");
        }
      
        return input;
    
    }
    
    private static boolean isValidVIN(String input){
        
        //create a variable to hold result
        boolean result = true;
       
        //Add code to validate the VIN number here
        try{
        
            if(!input.substring(0, 1).equals("V") || input.length() >6){
                result = false;
                
            }
        }catch(Exception ex){
            result = false;
        }
       
        
        return result;
    }
    public static String getValidMake(String input){
        while(isValidMake(input) == false){
        
            input = JOptionPane.showInputDialog(null, "Make: " + input + " is invalid\n\nPlease reenter a valid make");
        }
      
        return input;
    
    }
    private static boolean isValidMake(String input){
        boolean result = true;
        
        //add code
        try{
        
            if(input.length() >15){
                result = false;
                
            }
        }catch(Exception ex){
            result = false;
        }
       
        
        
        return result;
    }
    
    public static String getValidModel(String input){ 
        while(isValidModel(input) == false){
        
            input = JOptionPane.showInputDialog(null, "Model: " + input + " is invalid\n\nPlease reenter a valid model");
        }
      
        return input;
    }     
    
    
    private static boolean isValidModel(String input){
        boolean result = true;
        
        //add code
        try{
        
            if(input.length() >15){
                result = false;
                
            }
        }catch(Exception ex){
            result = false;
        }
       
        
        
       
        
        return result;
    }
    public static String getValidYear(String input){
         while(isValidYear(input) == false){
        
            input = JOptionPane.showInputDialog(null, "Year: " + input + " is invalid\n\nPlease reenter a valid year");
        }
      
        return input;
    
    
    
    }
    private static boolean isValidYear(String input){
        boolean result = true;
        
        //add code
        try{
        
            if (Integer.parseInt(input) > 2900 || Integer.parseInt(input) < 1900){
                result = false;
                
            }
        }catch(Exception ex){
            result = false;
        }
        
        return result; 
    }
}
    
    