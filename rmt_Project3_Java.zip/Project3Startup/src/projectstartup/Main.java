/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectstartup;

/**
 *
 * @author hmouissa
 */
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Main {

    private static HashMap<String, Car> inventory;

    public static void main(String[] args) {
        
       //initialize the inventory
       inventory = new HashMap<String, Car>();
       inventory = MaxCarDB.loadCars();
       
       
       //Present the customer with a choice of vehicles
		String[]  choices = {"Add Car", "Remove Car", "Update Car", "List Cars", "Clear Cars", "Find Car", "Exit"};

                //keep the menu up unless exiting
                while(true){ 
                    int response = JOptionPane.showOptionDialog(
                                    null                       				// center over parent
                                    , "Database Operations"                             // message
                                    , "MaxCar the Best Car Dealership"        		// title in titlebar
                                    , JOptionPane.YES_NO_OPTION                 	// Option type
                                    , JOptionPane.PLAIN_MESSAGE  			// messageType
                                    , null                       			// icon
                                    , choices                    			// Options
                                    , "Select a MaxCar Operation"                       // initial value
                    );
                    switch (response){

                        case 0:
                            addCar();
                            break;
                        case 1:
                            removeCar();
                            break;                      
                        case 2:
                            updateCar();
                            break;
                        case 3:
                            listCars();
                            break;
                        case 4:
                            clearCars();
                            break;
                        case 5:
                            findCar();
                            break;                            
                        default:
                               exitApplication();

                    }
                }
                      
    }
    
    
    private static void addCar(){
        //add code to ask user for entry
        String input = JOptionPane.showInputDialog("Enter the car information separated by spaces\n" + "\n" + "VIN CAR_MAKE CAR_MODEL CAR_YEAR");
        String[] values = input.split(" ");
       
        Car aCar = new Car(Validator.getValidVIN(values[0]), Validator.getValidMake(values[1]), Validator.getValidModel(values[2]), Validator.getValidYear(values[3]));
        
        inventory.put(aCar.getVin(), aCar);
        JOptionPane.showMessageDialog(null, input + " has been added!");
      
    }
    private static void removeCar(){
        //add code to ask user for data entry and remove a car from the hashmap
        String input = JOptionPane.showInputDialog("Please enter VIN number of car to REMOVE\n" + "\n" + "VIN");
        //Example using the validator class to check data for issues
        if (inventory.containsKey(input)) {
            //delete product
            inventory.remove(input);

            JOptionPane.showMessageDialog(null, input + " was removed!");
        } else {
            //product not found
            JOptionPane.showMessageDialog(null, input + " was not found!");
        }
     
    }
    
    private static void updateCar(){
    //add code to ask user for data entry and update the car in the hashmap
    String input = JOptionPane.showInputDialog("Please enter VIN number of car to UPDATE\n" + "\n" + "VIN");
    String vin = input;
    if (inventory.containsKey(vin)) {
       input = JOptionPane.showInputDialog("Enter the car information separated by spaces\n" + "\n" + "VIN CAR_MAKE CAR_MODEL CAR_YEAR");
        String[] values = input.split(" ");
        //I am using vin as the first element. in case user input different vin 
        Car aCar = new Car(vin, Validator.getValidMake(values[1]), Validator.getValidModel(values[2]), Validator.getValidYear(values[3]));

        inventory.put(aCar.getVin(), aCar);

        JOptionPane.showMessageDialog(null, input + " was updated!");
    } else {
        //product not found
        JOptionPane.showMessageDialog(null, input + " was not found!");
    }
}
    
    private static void listCars(){
        //add code to display summary data of all the cars in the hashmap
    String summary = "MAXCAR LISTING\n\n";
        for (Map.Entry<String, Car> anEntry : inventory.entrySet()) {

            summary += anEntry.getValue().getVin() + "\t" + anEntry.getValue().getMake() + "\t" + anEntry.getValue().getModel() + "\t" + anEntry.getValue().getYear() + "\n";
        }

        JOptionPane.showMessageDialog(null,new JTextArea(summary));
    }
    
    private static void clearCars(){
        //add code to clear the hashmap
        int numItems = inventory.size();
        inventory.clear();
         JOptionPane.showMessageDialog(null, numItems + " cars were cleared from Database!");
        
    
    }
    
    private static void findCar(){
        //add code to find the car in the hashmap
        String input = JOptionPane.showInputDialog("ENTER THE VIN OF THE CAR TO FIND\n" + "\n" + "VIN");
        if (inventory.containsKey(input)) {

            Car aCar = inventory.get(input);
            
            JOptionPane.showMessageDialog(null, aCar.getVin() + " " + aCar.getMake() + " " + aCar.getModel() + " " + aCar.getYear());

        } else {
            //product not found
            JOptionPane.showMessageDialog(null, input + " was not found!");
        }
    }
    
    
    private static void exitApplication(){
        JOptionPane.showMessageDialog(null, "Thank you for using the MaxCar Application. " + inventory.size() + " cars saved!...EXITING...");
        System.exit(0);
    }
    
}
