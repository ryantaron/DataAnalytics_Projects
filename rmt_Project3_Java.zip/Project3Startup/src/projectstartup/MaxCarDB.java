/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectstartup;

/**
 *
 * @author hmouissa
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class MaxCarDB {
    
    public static HashMap<String, Car>loadCars(){
        //add code to load data from the file into the hashmap
        HashMap<String,Car> carList = new HashMap<String, Car>();
        String fileName = "C:\\Users\\ryant\\Documents\\CIS3090_Cars.txt";
        
        try{
            FileInputStream fis = new FileInputStream(fileName);
            
            Scanner sc = new Scanner(fis);
            
            while(sc.hasNext()){
                String line = sc.nextLine();
                String[]values = line.split("\t");
                
                Car aCar = new Car(values[0], values[1], values[2], values[3]);
                carList.put(aCar.getVin(), aCar);
            }
            fis.close();
            JOptionPane.showMessageDialog(null, "File loaded succesfully\n\n" + fileName);
            
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "There was an error loading the file" + ex.getMessage());
        }
        
        return carList;
    }
    
    
    public static void saveCars(HashMap<String,Car> inventory){
        //add code to save data from the hashmap into a file
        String fileName = "C:\\Users\\ryant\\Documents\\CIS3090_Cars.txt";
        try{
            
        //open the stream       
        FileOutputStream fos = new FileOutputStream(fileName); 
        
        //create printwriter to write to file
        PrintWriter pw = new PrintWriter(fos);
        
        //loop through the hashmap and save data to the file
        for (Map.Entry<String, Car> anEntry : inventory.entrySet()) {

            pw.println(anEntry.getValue().getVin() + "\t" + anEntry.getValue().getMake() + "\t" + anEntry.getValue().getModel() + "\t" + anEntry.getValue().getYear());
        }
        
        pw.close();
        fos.flush();
        fos.close();
        
        JOptionPane.showMessageDialog(null, "Data saved to \n\n" + fileName);
        
        }catch(Exception ex){
         JOptionPane.showMessageDialog(null, "There was an issue saving data \n\n" + ex.getMessage());
        
    
    }
    }
    
}
